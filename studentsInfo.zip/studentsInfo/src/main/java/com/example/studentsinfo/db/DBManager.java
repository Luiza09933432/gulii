package com.example.studentsinfo.db;

import com.mysql.cj.protocol.Resultset;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DBManager {

    private static Connection connection;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/first_ee-db?useUnicode=true&serverTimezone=UTC", "root","");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static boolean addItem(Items item) {

        int rows = 0;

        try{
            PreparedStatement statement = connection.prepareStatement(""+
                    "INSERT INTO items (id, name, price, amount, manufacture_id) " +
                    "VALUES(NULL, ?, ?, ?, ?)" + " ");

            statement.setString(1, item.getName());
            statement.setInt(2, item.getPrice());
            statement.setInt(3, item.getAmount());
            statement.setLong(4, item.getManufacture().getId());

            rows = statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return rows>0;
    }

    public static boolean addCountry(Countries country) {

        int rows = 0;

        try{
            PreparedStatement statement = connection.prepareStatement(""+
                    "INSERT INTO countries (id, name, short_name) " +
                    "VALUES(NULL, ?, ?)" + " ");

            statement.setString(1, country.getName());
            statement.setString(2, country.getShortName());

            rows = statement.executeUpdate();
            statement.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return rows>0;
    }

    public static ArrayList<Items> getItems() {
       ArrayList<Items> items = new ArrayList<>();

       try {

           PreparedStatement statement = connection.prepareStatement(" "+
                   "SELECT it.id, it.name, it.amount, it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                   "FROM items it " +
                   "INNER JOIN countries c ON it.manufacture_id = c.id " +
                   "ORDER BY it.price DESC "
           );

           ResultSet resultSet = statement.executeQuery();


           while(resultSet.next()){

               items.add(new Items(
                  resultSet.getLong("id"),
                  resultSet.getString("name"),
                  resultSet.getInt("price"),
                  resultSet.getInt("amount"),
                  new Countries(
                               resultSet.getLong("manufacture_id"),
                               resultSet.getString("countryName"),
                               resultSet.getString("short_name")
                  )

               ));
           }

           statement.close();

       }catch (Exception e){
           e.printStackTrace();

       }

       return items;
    }

    public static Items getItem(long id) {

        Items item = null;
        try {

            PreparedStatement statement = connection.prepareStatement(" "+
                    "SELECT it.id, it.name, it.amount , it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                    "FROM items it " +
                    "INNER JOIN countries c ON it.manufacture_id = c.id " +
                    "WHERE it.id = ?");

            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();

            if(resultSet.next()){

                item = new Items(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("price"),
                        resultSet.getInt("amount"),
                        new Countries(
                                resultSet.getLong("manufacture_id"),
                                resultSet.getString("countryName"),
                                resultSet.getString("short_name")
                        )
                );
            }

            statement.close();

        }catch (Exception e){
            e.printStackTrace();

        }

        return item;

    }

    // Logical part of Delete and Update
    public static boolean saveItem(Items item){
        int rows = 0;
        try{

            PreparedStatement statement = connection.prepareStatement(" "+
                    "UPDATE items SET name = ?, price=?, amount=?, manufacture_id=? " +
                    "WHERE id = ?");

            statement.setString(1, item.getName());
            statement.setInt(2, item.getPrice());
            statement.setInt(3, item.getAmount());
            statement.setLong(4, item.getManufacture().getId());
            statement.setLong(5, item.getId());

            rows = statement.executeUpdate();
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }

        return rows>0;
    }

    public static boolean deleteItem(Items item){
        int rows = 0;
        try{

            PreparedStatement statement = connection.prepareStatement(""+
                    "DELETE FROM items WHERE id = ?");

            statement.setLong(1, item.getId());

            rows = statement.executeUpdate();
            statement.close();

        }catch (Exception e){
            e.printStackTrace();
        }

        return rows>0;
    }




    // Logical part of Searching with different options {ID, Name, Price, Amount}
    public static ArrayList<Items> searchItemWithName(String searchResult) {

        ArrayList<Items> items = new ArrayList<>();

        try {

            searchResult += "%";

            PreparedStatement statement = connection.prepareStatement(" " +
                            "SELECT it.id, it.name, it.amount , it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                            "FROM items it " +
                            "INNER JOIN countries c ON it.manufacture_id = c.id " +
                            "WHERE it.name LIKE '" + searchResult + "' " + " "
                    );

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                items.add(new Items(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("price"),
                        resultSet.getInt("amount"),
                new Countries(
                        resultSet.getLong("manufacture_id"),
                        resultSet.getString("countryName"),
                        resultSet.getString("short_name")
                )

                ));
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();

        }

        return items;

    }

    public static ArrayList<Items> searchItemWithId(int searchResult) {

        ArrayList<Items> items = new ArrayList<>();

        try {


            PreparedStatement statement = connection.prepareStatement(" " +
                    "SELECT it.id, it.name, it.amount , it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                    "FROM items it " +
                    "INNER JOIN countries c ON it.manufacture_id = c.id " +
                    "WHERE it.id LIKE '" + searchResult + "' " + " "
            );

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                items.add(new Items(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("price"),
                        resultSet.getInt("amount"),
                new Countries(
                        resultSet.getLong("manufacture_id"),
                        resultSet.getString("countryName"),
                        resultSet.getString("short_name")
                )
                ));
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();

        }

        return items;

    }

    public static ArrayList<Items> searchItemWithPrice(int searchResult) {

        ArrayList<Items> items = new ArrayList<>();

        try {


            PreparedStatement statement = connection.prepareStatement(" " +
                    "SELECT it.id, it.name, it.amount , it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                    "FROM items it " +
                    "INNER JOIN countries c ON it.manufacture_id = c.id " +
                    "WHERE it.price LIKE '" + searchResult + "' " + " "
            );

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                items.add(new Items(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("price"),
                        resultSet.getInt("amount"),
                        new Countries(
                                resultSet.getLong("manufacture_id"),
                                resultSet.getString("countryName"),
                                resultSet.getString("short_name")
                        )
                ));
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();

        }

        return items;

    }

    public static ArrayList<Items> searchItemWithAmount(int searchResult) {

        ArrayList<Items> items = new ArrayList<>();

        try {


            PreparedStatement statement = connection.prepareStatement(" " +
                    "SELECT it.id, it.name, it.amount , it.price, it.manufacture_id, c.name AS countryName, c.short_name " +
                    "FROM items it " +
                    "INNER JOIN countries c ON it.manufacture_id = c.id " +
                    "WHERE it.amount LIKE '" + searchResult + "' " + " "
            );

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                items.add(new Items(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getInt("price"),
                        resultSet.getInt("amount"),
                        new Countries(
                                resultSet.getLong("manufacture_id"),
                                resultSet.getString("countryName"),
                                resultSet.getString("short_name")
                        )
                ));
            }

            statement.close();

        } catch (Exception e) {
            e.printStackTrace();

        }

        return items;

    }

    public static ArrayList<Countries> getCountries() {
        ArrayList<Countries> countries = new ArrayList<>();

        try {

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM countries");

            ResultSet resultSet = statement.executeQuery();


            while(resultSet.next()){
                countries.add(new Countries(
                   resultSet.getLong("id"),
                   resultSet.getString("name"),
                   resultSet.getString("short_name")
                ));
            }

            statement.close();

        }catch (Exception e){
            e.printStackTrace();

        }

        return countries;
    }


    public static Countries getCountry(Long id) {

        Countries country = null;

        try {

            PreparedStatement statement = connection.prepareStatement("SELECT * FROM countries WHERE id=? LIMIT 1");
            statement.setLong(1, id);
            ResultSet resultSet = statement.executeQuery();


            while(resultSet.next()){
                country = new Countries(
                        resultSet.getLong("id"),
                        resultSet.getString("name"),
                        resultSet.getString("short_name")
                );
            }

            statement.close();

        }catch (Exception e){
            e.printStackTrace();

        }

        return country;
    }
}