package com.example.studentsinfo.servlets;


import com.example.studentsinfo.db.Countries;
import com.example.studentsinfo.db.DBManager;
import com.example.studentsinfo.db.Items;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(value = "/addcountry")
public class AddCountryServlet extends HttpServlet {


    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String countryName = req.getParameter("CountryName");
        String countrySN = req.getParameter("CountryShortName");

        if(countryName!=null){
            Countries ct = new Countries(null, countryName, countrySN);
            DBManager.addCountry(ct);
            resp.sendRedirect("/additem?success");
        }else{
            resp.sendRedirect("/additem?error");
        }

    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/AddCountry.jsp").forward(req, resp);
    }
}
